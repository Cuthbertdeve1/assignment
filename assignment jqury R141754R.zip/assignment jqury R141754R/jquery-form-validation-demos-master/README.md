jQuery Form Validation Demos
============================

Basic Demo: Setup front-end form validation using jQuery in just a few minutes.

Demos to be added soon:

- bootstrap support for validation
- conditional success error functions
- remote ajax validation
- different forms: login, register, contact, forgot password etc...
- regex support
- custom field validation
- validate messages as groups
- think of more? fork and submit a pull request! =)

Thanks!